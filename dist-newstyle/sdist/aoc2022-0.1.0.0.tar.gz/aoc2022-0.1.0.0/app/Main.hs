module Main where
import Data.List

main :: IO ()
main = putStrLn "Hello, Haskell!"
