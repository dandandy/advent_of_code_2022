module Main where

import Day1
import Day2
import Helper

main :: IO ()
main = putStrLn "Hello, Haskell!"
