module Day5 where

import Data.Stack

parse :: Parsec String String [Stack]
