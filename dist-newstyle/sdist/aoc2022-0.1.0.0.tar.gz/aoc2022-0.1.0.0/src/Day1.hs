module Day1 where

day1part1 :: String -> String
day1part1 = show . resultDay1part1 . parseDay1

parseDay1 :: String -> [[Int]]
parseDay1 a = (map (read) . filter (/= "\n")) (lines a)

resultDay1part1 :: [[Int]] -> Int
resultDay1part1 = maximum . head
