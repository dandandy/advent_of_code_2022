module Day8 where

import Data.Matrix
import Text.Parsec
import Data.List (sort)
import Data.Vector (slice)

parse' :: Parsec String String (Matrix Int)
parse' = fromLists <$> (many1 (read . (:[]) <$> digit) `sepEndBy` newline)

isVisable :: (Int, Int) -> Matrix Int -> Bool
isVisable (a, b) m = 
    where
        row = getRow a
        col = getCol b

        (rowStart, rowEnd) = slice



isIncreasing :: [Int] -> Bool
isIncreasing as = as == sort as
